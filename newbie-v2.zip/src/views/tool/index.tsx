import React from 'react';

function Page() {
  return <h2>TOOL</h2>;
}

export default Page;